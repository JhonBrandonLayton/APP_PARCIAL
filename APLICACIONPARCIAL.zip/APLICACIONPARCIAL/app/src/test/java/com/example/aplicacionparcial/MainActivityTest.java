package com.example.aplicacionparcial;

import junit.framework.TestCase;

import org.junit.Test;

public class MainActivityTest extends TestCase {

    @Test
    public void testIngresar(){
        MainActivityTest MainActivity = new MainActivityTest();

    }

}