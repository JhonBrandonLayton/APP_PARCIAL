package com.example.aplicacionparcial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView nombreUsuario;
    private TextView apellidoUsuario;

    private String input = "";
    private String input2 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        nombreUsuario = findViewById(R.id.btnNombre);
        apellidoUsuario = findViewById(R.id.btnApellido);

    }

    public void botonIngresar(View view) {

            //crear intent
            Intent intent = new Intent(this, VentanaCompras.class);

            //inicializar intent
            startActivity(intent);
    }
}