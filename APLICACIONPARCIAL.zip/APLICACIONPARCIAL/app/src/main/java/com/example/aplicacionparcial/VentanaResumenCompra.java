package com.example.aplicacionparcial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class VentanaResumenCompra extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana_resumen_compra);

        TextView TextViewResultadoCompra = findViewById(R.id.TextViewResultadoCompra);

        TextViewResultadoCompra.setText("Opcion1");

    }
}